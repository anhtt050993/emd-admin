<?php

namespace App\Filament\Resources;

use App\Filament\Resources\RestrictAddressResource\Pages;
use App\Models\RestrictAddress;
use Filament\Forms\Components;
use Filament\Resources\{
    Form,
    Resource,
    Table,
};
use Filament\Tables\Actions\{
    DeleteAction,
    DeleteBulkAction,
};
use Filament\Tables\Filters\Filter;
use Filament\Tables\Columns\TextColumn;
use Illuminate\Database\Eloquent\Builder;

class RestrictAddressResource extends Resource
{
    protected static ?string $model = RestrictAddress::class;

    protected static ?string $slug = 'restrict-address';

    protected static ?string $navigationIcon = 'heroicon-o-lock-closed';

    protected static function getNavigationLabel(): string
    {
        return __('Restrict Addresses');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Components\TextInput::make('recipient')->email()->required()->unique()->label(__('Recipient')),
            Components\Hidden::make('access')->default('REJECT'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('recipient')->label(__('Recipient')),
            TextColumn::make('access')->label(__('Access')),
            TextColumn::make('created_at')->dateTime()->sortable()->label(__('Created At')),
        ])->filters([
            Filter::make('recipient')->form([
                Components\TextInput::make('recipient'),
            ])->query(function (Builder $query, array $data) {
                return empty($data['recipient']) ? $query
                    : $query->where('recipient', $data['recipient']);
            }),
        ])->actions([
            DeleteAction::make(),
        ])->bulkActions([
            DeleteBulkAction::make(),
        ]);
    }
    
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListRestrictAddresses::route('/'),
            'create' => Pages\CreateRestrictAddress::route('/create'),
        ];
    }    
}
