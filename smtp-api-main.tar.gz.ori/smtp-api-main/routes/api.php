<?php

use App\Http\Controllers\{
    EmailController,
    UploadController,
};
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::middleware(['auth:sanctum', 'ability:api-email'])->controller(
    EmailController::class
)->group(function () {
    Route::get('/email', 'index');
    Route::get('/email/{id}', 'show');
    Route::get('/email/{id}/devices', 'devices');
    Route::post('/send', 'send');
});

Route::middleware(['auth:sanctum', 'ability:api-upload'])->post(
    '/upload',
    [UploadController::class, 'upload']
);
