<?php

use App\Http\Controllers\{
    LoginController,
    TrackingController,
};
use Illuminate\Support\Facades\Route;
use Laravel\Sanctum\Http\Controllers\CsrfCookieController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::controller(TrackingController::class)->prefix('tracking')->group(function () {
    Route::get('/open/{idHash}.gif', 'openImage')->name('tracking_open');
    Route::get('/click/{idHash}', 'clickUrl')->name('tracking_click');
});

Route::any('/login/csrf-cookie', [CsrfCookieController::class, 'show']);
Route::post('/login/token', [LoginController::class, 'createToken']);

Route::get('/', function () {
    return redirect(env('FILAMENT_PATH', 'admin'));
});
