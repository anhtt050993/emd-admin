<?php declare(strict_types=1);

namespace App\Http\Controllers;

use App\Mail\SendMessage;
use App\Models\{
    Message,
    MessageFailure,
};
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\{
    Cache,
    Log,
    Mail,
};
use Illuminate\Validation\ValidationException;
use Ramsey\Uuid\Uuid;
use Symfony\Component\Mailer\Exception\ExceptionInterface as MailerException;

/**
 * Email API controller.
 *
 * @package  App
 * @category Controllers
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class EmailController extends Controller
{
    const QUEUE_NAME = 'emails';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        JsonResource::withoutWrapping();
    }

    /**
     * List messages.
     *
     * @param  Request $request
     * @return JsonResource
     */
    public function index(Request $request): JsonResource
    {
        return JsonResource::collection(
            Message::where([
                'user_id' => $request->user()->id,
            ])->paginate()
        );
    }

    /**
     * Show a message.
     *
     * @param  Request $request
     * @param  int $id
     * @return JsonResource
     */
    public function show(Request $request, int $id): JsonResource
    {
        return new JsonResource(Message::firstWhere([
            'id'      => $id,
            'user_id' => $request->user()->id,
        ]));
    }

    /**
     * Show message devices.
     *
     * @param  Request $request
     * @param  int $id
     * @return JsonResource
     */
    public function devices(Request $request, int $id): JsonResource
    {
        $message = Message::firstWhere([
            'id'      => $id,
            'user_id' => $request->user()->id,
        ]);
        return new JsonResource($message?->devices ?? []);
    }

    /**
     * Send a message.
     *
     * @param  Request $request
     * @return JsonResource
     */
    public function send(Request $request): JsonResource
    {
        $request->validate([
            'recipients' => 'required',
            'message_id' => 'required',
            'subject'    => 'required',
            'content'    => 'required',
        ]);

        $message = new Message([
            'hash'       => Uuid::uuid4()->toString(),
            'user_id'    => $request->user()->id,
            'from_name'  => $request->user()->name,
            'from_email' => $request->user()->email,
            'reply_to'   => $request->reply_to ?? $request->user()->email,
            'message_id' => $request->message_id,
            'subject'    => $request->subject,
            'content'    => $request->content,
            'ip_address' => $request->ip(),
        ]);

        $recipients = $request->recipients;
        if (is_array($recipients)) {
            $message->recipients = array_filter(
                $recipients,
                static fn($recipient) => filter_var(
                    $recipient, FILTER_VALIDATE_EMAIL
                )
            );
        }
        elseif (filter_var($recipients, FILTER_VALIDATE_EMAIL)) {
            $message->recipients = [$recipients];
        }

        if (empty($message->recipients)) {
            throw ValidationException::withMessages([
                'recipients' => ['The recipients are incorrect.'],
            ]);
        }

        $headers = $request->input('headers');
        if (is_array($headers)) {
            $message->headers = $headers;
        }

        $uploads = $request->uploads;
        if (is_array($uploads)) {
            foreach ($uploads as $upload) {
                if ($path = Cache::get($upload)) {
                    $message->uploads[] = $path;
                }
            }
        }

        $failed = false;
        try {
            $shouldQueue = (bool) env('MAIL_SHOULD_QUEUE', false);
            if ($shouldQueue) {
                Mail::to($message->recipients)->queue(
                    (new SendMessage($message))->onQueue(
                        env('MAIL_QUEUE_NAME', self::QUEUE_NAME)
                    )
                );
            }
            else {
                Mail::to($message->recipients)->send(
                    new SendMessage($message)
                );
            }
            $message->sent_at = now();
        }
        catch (MailerException $e) {
            Log::error($e);
            $failed = $e;
        }
        $message->save();

        if ($failed) {
            return new JsonResource(MessageFailure::create([
                'message_id'  => $message->id,
                'severity'    => __('Send message failed'),
                'description' => $failed->getMessage(),
                'failed_at'   => now(),
            ]));
        }

        return new JsonResource($message);
    }
}
