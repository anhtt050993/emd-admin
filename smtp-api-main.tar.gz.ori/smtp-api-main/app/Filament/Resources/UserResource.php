<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Models\User;
use Filament\Forms\Components\TextInput;
use Filament\Resources\{
    Form,
    Resource,
    Table,
};
use Filament\Tables\Actions\{
    DeleteAction,
    EditAction,
};
use Filament\Tables\Columns\TextColumn;
use Illuminate\Support\Facades\Hash;

/**
 * User resource manager.
 *
 * @package  App
 * @category Resources
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class UserResource extends Resource
{
    protected static ?string $model = User::class;
    protected static ?string $slug = 'user';
    protected static ?string $navigationIcon = 'heroicon-o-user';

    protected static function getNavigationLabel(): string
    {
        return __('User Manager');
    }

    public static function getModelLabel(): string
    {
        return __('User');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('name')->required()->label(__('Name')),
            TextInput::make('email')->email()->required()->label(__('Email Address')),
            TextInput::make('password')->password()
                ->dehydrateStateUsing(fn ($state) => Hash::make($state))
                ->dehydrated(fn ($state) => filled($state))
                ->required(fn (string $context): bool => $context === 'create')
                ->label(__('Password')),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->sortable()->label(__('Name')),
            TextColumn::make('email')->sortable()->label(__('Email')),
            TextColumn::make('created_at')->dateTime()->sortable()->label(__('Created At')),
        ])->actions([
            EditAction::make(),
            DeleteAction::make(),
        ])->bulkActions([]);
    }

    public static function getRelations(): array
    {
        return [
            UserResource\RelationManagers\TokensRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => UserResource\Pages\ListUsers::route('/'),
            'create' => UserResource\Pages\CreateUser::route('/create'),
            'edit'   => UserResource\Pages\EditUser::route('/{record}/edit'),
        ];
    }
}
