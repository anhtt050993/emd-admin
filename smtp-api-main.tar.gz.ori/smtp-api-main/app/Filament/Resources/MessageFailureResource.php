<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Filament\Resources\MessageFailureResource\Pages;
use App\Models\MessageFailure;
use Filament\Resources\{
    Resource,
    Table,
};
use Filament\Tables\Actions\{
    DeleteAction,
    ViewAction,
};
use Filament\Tables\Columns\TextColumn;

/**
 * Message failure resource manager.
 *
 * @package  App
 * @category Resources
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class MessageFailureResource extends Resource
{
    protected static ?string $model = MessageFailure::class;
    protected static ?string $navigationIcon = 'heroicon-o-mail';
    protected static ?string $slug = 'message-failure';

    protected static function getNavigationGroup(): string
    {
        return __('Message');
    }

    protected static function getNavigationLabel(): string
    {
        return __('Failures');
    }

    public static function getModelLabel(): string
    {
        return __('Message Failure');
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('message.subject')->label(__('Message'))->wrap(),
            TextColumn::make('severity')->label(__('Severity'))->wrap(),
            TextColumn::make('description')->label(__('Description'))->wrap(),
            TextColumn::make('failed_at')->label(__('Failed At'))->dateTime()->sortable(),
        ])->defaultSort('failed_at', 'desc')->actions([
            ViewAction::make(),
            DeleteAction::make(),
        ])
        ->bulkActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMessageFailures::route('/'),
            'view' => Pages\ViewMessageFailure::route('/{record}'),
        ];
    }    
}
