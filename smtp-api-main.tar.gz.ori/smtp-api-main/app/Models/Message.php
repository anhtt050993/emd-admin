<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\{
    BelongsTo,
    HasMany,
};
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Ramsey\Uuid\Uuid;

/**
 * Message model.
 *
 * @package  App
 * @category Models
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class Message extends Model
{
    use HasFactory;

    protected $table = 'messages';

    protected $casts = [
        'headers'    => 'array',
        'recipients' => 'array',
    ];

    protected $fillable = [
        'user_id',
        'hash',
        'from_name',
        'from_email',
        'reply_to',
        'recipients',
        'headers',
        'message_id',
        'subject',
        'content',
        'ip_address',
        'open_count',
        'click_count',
        'sent_at',
        'last_opened',
        'last_clicked',
    ];

    public array $uploads = [];

    /**
     * The "booting" method of the model.
     *
     * @return void
     */
    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (self $model) {
            $model->hash = $model->hash ?: Uuid::uuid4()->toString();
        });

        static::created(function (self $model) {
            foreach ($model->uploads as $upload) {
                Attachment::create([
                    'message_id' => $model->id,
                    'file_name' => basename($upload),
                    'file_path' => $upload,
                    'file_mime' => Storage::mimeType($upload),
                    'file_size' => Storage::size($upload),
                ]);
            }
        });

        static::deleting(function (self $model) {
            $model->attachments()->delete();
            $model->devices()->delete();
            $model->failures()->delete();
            $model->urls()->delete();
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function attachments(): HasMany
    {
        return $this->hasMany(Attachment::class);
    }

    public function devices(): HasMany
    {
        return $this->hasMany(MessageDevice::class);
    }

    public function failures(): HasMany
    {
        return $this->hasMany(MessageFailure::class)
            ->orderBy('failed_at');
    }

    public function urls(): HasMany
    {
        return $this->hasMany(MessageUrl::class);
    }
}
