<?php declare(strict_types=1);

namespace App\Filament\Resources\DmarcReportResource\Pages;

use App\Filament\Resources\DmarcReportResource;
use App\Support\DmarcScanner;
use Elastic\Elasticsearch\ClientBuilder;
use Filament\Actions\Action;
use Filament\Forms\{
    Components\Fieldset,
    Components\Grid,
    Components\Select,
    Components\Toggle,
    Components\TextInput,
    Form,
    Get,
};
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Database\Eloquent\Model;
use Webklex\PHPIMAP\ClientManager;

class ScanDmarcReport extends CreateRecord
{
    const IMAP_ACCOUNT = 'dmarc_mailbox';

    protected static string $resource = DmarcReportResource::class;
    protected static bool $canCreateAnother = false;

    public function getTitle(): string
    {
       return  __('Scan DMARC Report');
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            Fieldset::make(__('IMAP Mailbox'))->schema([
                Grid::make(5)->schema([
                    TextInput::make('host')->required()->columnSpan(3)->label(__('IMAP Host')),
                    TextInput::make('port')->required()->numeric()->default(143)->label(__('IMAP Port')),
                    Select::make('encryption')->required()->options([
                        'none' => __('None'),
                        'starttls' => 'STARTTLS',
                        'tls' => 'TLS',
                        'ssl' => 'SSL',
                    ])->default('starttls')->label(__('Encryption')),
                ]),
                Grid::make(4)->schema([
                    TextInput::make('username')->required()->label(__('User Name')),
                    TextInput::make('password')->required()->password()->label(__('Password')),
                    TextInput::make('report_folder')->required()->label(__('Report Folder')),
                    TextInput::make('archive_folder')->required()->label(__('Archive Folder')),
                ]),
            ]),
            Toggle::make('index_report')->inline(false)->live()->label(__('Index Report')),
            Fieldset::make(__('Elastic Search API'))->schema([
                Grid::make(3)->schema([
                    TextInput::make('elastic_host')->required()->url()->label(__('Host')),
                    TextInput::make('elastic_api_id')->required()->label(__('API Id')),
                    TextInput::make('elastic_api_key')->required()->label(__('API Key')),
                ]),
            ])->hidden(fn (Get $get) => !$get('index_report')),
        ]);
    }

    protected function handleRecordCreation(array $data): Model
    {
        $cm = new ClientManager([
            'options' => [
                'soft_fail' => true,
            ],
        ]);

        $esClient = null;
        if (!empty($data['index_report'])) {
            $esClient = ClientBuilder::create()
                ->setHosts([
                    $data['elastic_host'],
                ])
                ->setApiKey(
                    $data['elastic_api_id'],
                    $data['elastic_api_key']
                )
                ->build();
        }

        $scanner = new DmarcScanner(
            $cm->make([
                'host' => $data['host'],
                'port' => $data['port'],
                'encryption' => $data['encryption'],
                'username' => $data['username'],
                'password' => $data['password'],
            ])->connect(),
            $esClient
        );
        $scanner->scan(
            $data['report_folder'],
            $data['archive_folder']
        );
        $model = self::getResource()::getModel();
        return new $model;
    }

    protected function getCreatedNotificationTitle(): ?string
    {
        return __('Scan DMARC Report Completed!');
    }

    protected function getCreateFormAction(): Action
    {
        return parent::getCreateFormAction()->label(__('Scan'));
    }

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl();
    }
}
