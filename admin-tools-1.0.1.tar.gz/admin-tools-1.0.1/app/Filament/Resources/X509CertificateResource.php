<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Filament\Resources\X509CertificateResource\Pages;
use App\Models\X509Certificate;
use Filament\Resources\Resource;

class X509CertificateResource extends Resource
{
    protected static ?string $model = X509Certificate::class;
    protected static ?string $navigationGroup = 'X509';
    protected static ?string $navigationIcon = 'heroicon-o-identification';
    protected static ?string $slug = 'x509/certificate';

    public static function getModelLabel(): string
    {
        return __('Certificate');
    }

    public static function getNavigationLabel(): string
    {
        return __('Certificates');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListX509Certificates::route('/'),
        ];
    }
}
