<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Enums\Role;
use App\Filament\Resources\X509SigningRequestResource\Pages;
use App\Filament\Resources\X509SigningRequestResource\RelationManagers;
use App\Models\X509SigningRequest;
use Filament\Resources\Resource;

class X509SigningRequestResource extends Resource
{
    const PASSWORD_STORAGE = 'x509-key-password';

    protected static ?string $model = X509SigningRequest::class;
    protected static ?string $navigationGroup = 'X509';
    protected static ?string $navigationIcon = 'heroicon-o-key';
    protected static ?string $slug = 'x509/signing-request';

    public static function getModelLabel(): string
    {
        return __('Signing Request');
    }

    public static function getNavigationLabel(): string
    {
        return __('Signing Requests');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListX509SigningRequests::route('/'),
            'create' => Pages\CreateX509SigningRequest::route('/create'),
            'view' => Pages\ViewX509SigningRequest::route('/{record}'),
        ];
    }

    public static function getRelations(): array
    {
        return [
            RelationManagers\CertificatesRelationManager::class,
        ];
    }
}
