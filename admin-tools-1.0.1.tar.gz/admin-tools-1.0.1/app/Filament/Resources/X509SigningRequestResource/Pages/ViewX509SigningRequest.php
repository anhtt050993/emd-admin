<?php declare(strict_types=1);

namespace App\Filament\Resources\X509SigningRequestResource\Pages;

use App\Enums\X509KeyAlgorithm;
use App\Filament\Resources\X509SigningRequestResource;
use App\Support\Helper;
use Filament\Actions\Action;
use Filament\Infolists\Components\{
    Fieldset,
    RepeatableEntry,
    TextEntry,
};
use Filament\Infolists\Infolist;
use Filament\Resources\Pages\ViewRecord;

class ViewX509SigningRequest extends ViewRecord
{
    protected static string $resource = X509SigningRequestResource::class;
    protected ?string $previousUrl = null;

    public function getTitle(): string
    {
        return __('View Signing Request');
    }

    public function mount(int | string $record): void
    {
        parent::mount($record);
        $this->previousUrl = url()->previous();
    }

    public function infolist(Infolist $infolist): Infolist
    {
        return $infolist->schema([
            Fieldset::make(__('Certificate Information'))->schema([
                TextEntry::make('cn')->label(__('Common Name')),
                TextEntry::make('country')->label(__('Country')),
                TextEntry::make('state')->label(__('State / Province')),
                TextEntry::make('locality')->label(__('Locality')),
                TextEntry::make('organization')->label(__('Organization')),
                TextEntry::make('organization_unit')->label(__('Organization Unit')),
            ]),
            Fieldset::make(__('Key Information'))->schema([
                TextEntry::make('key_algorithm')->formatStateUsing(
                    fn (int $state) => X509KeyAlgorithm::tryFrom($state)
                )->label(__('Key Algorithm')),
                TextEntry::make('key_strength')
                    ->suffix(' bits')->label(__('Key Strength')),
            ]),
        ]);
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('export_key')->label(__('Export Key'))
                ->icon('heroicon-m-arrow-down-tray')
                ->action(
                    fn ($record) => Helper::exportX509Key($record)
                ),
            Action::make('export_csr')->label(__('Export Csr'))
                ->icon('heroicon-m-arrow-down-tray')
                ->action(
                    fn ($record) => Helper::exportX509Csr($record)
                ),
            Action::make('back')->url(
                $this->previousUrl ?? self::getResource()::getUrl()
            )->color('gray')->label(__('Back')),
        ];
    }
}
