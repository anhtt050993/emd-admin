<?php declare(strict_types=1);

namespace App\Filament\Resources\DkimKeyResource\Pages;

use App\Filament\Resources\DkimKeyResource;
use App\Models\Domain;
use App\Models\DkimKey;
use Filament\Actions\Action;
use Filament\Forms\{
    Components\Hidden,
    Components\Select,
    Components\TextInput,
    Form,
    Get,
};
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Database\Eloquent\Model;
use phpseclib3\Crypt\RSA;

class GenDkimKey extends CreateRecord
{
    protected static string $resource = DkimKeyResource::class;
    protected static bool $canCreateAnother = false;

    public function getTitle(): string
    {
       return  __('Generate DKIM Key');
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            Select::make('domain_id')
                ->options(
                    Domain::all()->pluck('name', 'id')
                )->required()->label(__('Domain')),
            TextInput::make('selector')
                ->rules([
                    fn (Get $get) => function (string $attribute, $value, \Closure $fail) use ($get) {
                        $exist = DkimKey::where('selector', $value)
                            ->where('domain_id', $get('domain_id'))
                            ->count();
                        if ($exist > 0) {
                            $fail(__('The selector already exist.'));
                        }
                    },
                ])
                ->required()->label(__('Selector')),
            Select::make('key_bits')->required()->options([
                1024 => '1024 bits',
                2048 => '2048 bits',
            ])->default(1024)->label(__('Key Bits')),
            Hidden::make('created_by')->default(auth()->user()->id),
        ]);
    }

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $selector = $data['selector'];
        $privateKey = RSA::createKey((int) $data['key_bits']);

        $dnsRecord = "$selector._domainkey\tIN\tTXT\t ( \"v=DKIM1; k=rsa; h=sha256; t=s; p=";
        $pubLines = explode("\n", $privateKey->getPublicKey()->toString('PKCS8'));
        foreach ($pubLines as $line) {
            if (strpos($line, '-----') !== 0) {
                $dnsRecord .= trim($line);
            }
        }
        $dnsRecord .= '" ) ;';

        $data['private_key'] = $privateKey->toString('PKCS8');
        $data['dns_record'] = $dnsRecord;
        return $data;
    }

    protected function getCreateFormAction(): Action
    {
        return parent::getCreateFormAction()->label(__('Generate'));
    }

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl();
    }
}
