<?php declare(strict_types=1);

namespace App\Filament\Resources\DomainResource\Pages;

use Amp\Dns\DnsRecord;
use Amp\Dns\DnsException;
use App\Filament\Resources\DomainResource;
use App\Models\Domain;
use Filament\Actions\CreateAction;
use Filament\Infolists\Components\TextEntry;
use Filament\Tables\{
    Actions\Action,
    Actions\ActionGroup,
    Actions\EditAction,
    Columns\TextColumn,
    Table,
};
use Filament\Resources\Pages\ListRecords;

class ListDomains extends ListRecords
{
    const RECORD_FORMAT = "%-10s %-56s\r\n";

    protected static string $resource = DomainResource::class;

    public function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->label(__('Name')),
            TextColumn::make('email')->label(__('Email')),
            TextColumn::make('organization')->label(__('Organization')),
        ])->actions([
            ActionGroup::make([
                EditAction::make(),
                Action::make('query_mx_records')
                    ->infolist([
                        TextEntry::make('mx_records')
                            ->state(fn ($record) => self::queryMxRecords($record))
                            ->html()->label(__('Result')),
                    ])
                    ->modalHeading(__('Query MX Records'))
                    ->modalSubmitAction(false)
                    ->icon('heroicon-m-eye')->label(__('Query MX Records')),
                Action::make('query_txt_records')
                    ->infolist([
                        TextEntry::make('txt_records')
                            ->state(fn ($record) => self::queryTxtRecords($record))
                            ->html()->label(__('Result')),
                    ])
                    ->modalHeading(__('Query TXT Records'))
                    ->modalSubmitAction(false)
                    ->icon('heroicon-m-eye')->label(__('Query TXT Records')),
                Action::make('query_dmarc_record')
                    ->infolist([
                        TextEntry::make('dmarc_record')
                            ->state(fn ($record) => self::queryDmarcRecord($record))
                            ->html()->label(__('Result')),
                    ])
                    ->modalHeading(__('Query Dmarc Record'))
                    ->modalSubmitAction(false)
                    ->icon('heroicon-m-eye')->label(__('Query Dmarc Record')),
            ]),
        ]);
    }

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()->label(__('New Domain')),
        ];
    }

    private static function queryMxRecords(Domain $domain): string
    {
        try {
            $records = array_map(
                fn ($record) => self::prettyPrintRecord($record),
                \Amp\Dns\query(
                    $domain->name, DnsRecord::MX
                )
            );
            return implode('<br />', $records);
        }
        catch (DnsException $e) {
            return $e->getMessage();
        }
    }

    private static function queryTxtRecords(Domain $domain): string
    {
        try {
            $records = array_map(
                fn ($record) => self::prettyPrintRecord($record),
                \Amp\Dns\query(
                    $domain->name, DnsRecord::TXT
                )
            );
            return implode('<br />', $records);
        }
        catch (DnsException $e) {
            return $e->getMessage();
        }
    }

    private static function queryDmarcRecord(Domain $domain): string
    {
        try {
            $records = array_map(
                fn ($record) => self::prettyPrintRecord($record),
                \Amp\Dns\query(
                    '_dmarc.' . $domain->name, DnsRecord::TXT
                )
            );
            return implode('<br />', $records);
        }
        catch (DnsException $e) {
            return $e->getMessage();
        }
    }

    private static function prettyPrintRecord(DnsRecord $record): string
    {
        return sprintf(
            self::RECORD_FORMAT,
            DnsRecord::getName($record->getType()),
            $record->getValue()
        );
    }
}
