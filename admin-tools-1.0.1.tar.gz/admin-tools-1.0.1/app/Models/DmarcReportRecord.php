<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Model;

class DmarcReportRecord extends Model
{
    use HasFactory;

    protected $table = 'dmarc_report_records';

    protected $fillable = [
        'report_id',
        'source_ip',
        'count',
        'header_from',
        'envelope_from',
        'envelope_to',
        'disposition',
        'dkim',
        'spf',
        'reason',
        'dkim_domain',
        'dkim_selector',
        'dkim_result',
        'spf_domain',
        'spf_result',
        'created_by',
        'updated_by',
    ];

    public function report(): BelongsTo
    {
        return $this->belongsTo(DmarcReport::class, 'report_id', 'report_id');
    }
}
