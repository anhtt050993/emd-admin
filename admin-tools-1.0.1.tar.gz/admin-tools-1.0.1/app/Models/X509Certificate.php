<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\{
    Factories\HasFactory,
    Relations\BelongsTo,
    Model,
};

class X509Certificate extends Model
{
    use HasFactory;

    protected $table = 'x509_certificates';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'domain_id',
        'signing_request_id',
        'serial_number',
        'subject_dn',
        'issuer_dn',
        'not_before',
        'not_after',
        'certificate_data',
        'created_by',
        'updated_by',
    ];

    public function domain(): BelongsTo
    {
        return $this->belongsTo(Domain::class, 'domain_id')->withDefault();
    }

    public function csr(): BelongsTo
    {
        return $this->belongsTo(X509SigningRequest::class, 'signing_request_id')->withDefault();
    }
}
