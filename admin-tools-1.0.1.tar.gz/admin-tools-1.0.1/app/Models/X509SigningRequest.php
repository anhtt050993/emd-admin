<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\{
    Factories\HasFactory,
    Relations\BelongsTo,
    Relations\HasMany,
    Model,
};

class X509SigningRequest extends Model
{
    use HasFactory;

    protected $table = 'x509_signing_requests';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'domain_id',
        'cn',
        'country',
        'state',
        'locality',
        'organization',
        'organization_unit',
        'fingerprint',
        'key_algorithm',
        'key_strength',
        'with_password',
        'key_data',
        'csr_data',
        'created_by',
        'updated_by',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'with_password' => 'boolean',
    ];

    public function domain(): BelongsTo
    {
        return $this->belongsTo(Domain::class, 'domain_id')->withDefault();
    }

    public function certificates(): HasMany
    {
        return $this->hasMany(X509Certificate::class, 'signing_request_id');
    }
}
