<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\{
    Factories\HasFactory,
    Relations\BelongsTo,
    Model,
};

class DkimKey extends Model
{
    use HasFactory;

    protected $table = 'dkim_keys';

    protected $fillable = [
        'domain_id',
        'selector',
        'key_bits',
        'private_key',
        'dns_record',
        'created_by',
        'updated_by',
    ];

    public function domain(): BelongsTo
    {
        return $this->belongsTo(Domain::class, 'domain_id')->withDefault();
    }
}
