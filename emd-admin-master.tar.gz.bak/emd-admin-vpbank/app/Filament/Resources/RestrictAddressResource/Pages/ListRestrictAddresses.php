<?php declare(strict_types=1);

namespace App\Filament\Resources\RestrictAddressResource\Pages;

use App\Filament\Resources\RestrictAddressResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ListRecords;

/**
 * List restrict address record class
 *
 * @package  App
 * @category Filament
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class ListRestrictAddresses extends ListRecords
{
    protected static string $resource = RestrictAddressResource::class;

    protected function getActions(): array
    {
        return [
            Actions\CreateAction::make()->label(__('Create Restrict Addresses')),
        ];
    }
}
