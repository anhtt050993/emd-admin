<?php declare(strict_types=1);

namespace App\Filament\Resources\RestrictAddressResource\Pages;

use App\Filament\Resources\RestrictAddressResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\EditRecord;

/**
 * Edit restrict address record class
 *
 * @package  App
 * @category Filament
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class EditRestrictAddress extends EditRecord
{
    protected static string $resource = RestrictAddressResource::class;

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }

    protected function getSavedNotificationTitle(): ?string
    {
        return __('Restrict address has been saved');
    }

    protected function getActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
