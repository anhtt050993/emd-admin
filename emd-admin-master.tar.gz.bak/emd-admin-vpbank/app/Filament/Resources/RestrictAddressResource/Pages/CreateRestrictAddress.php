<?php declare(strict_types=1);

namespace App\Filament\Resources\RestrictAddressResource\Pages;

use App\Filament\Resources\RestrictAddressResource;
use Filament\Forms\Components;
use Filament\Resources\Form;
use Filament\Resources\Pages\CreateRecord;
use Filament\Support\Exceptions\Halt;
use Illuminate\Database\Eloquent\Model;

/**
 * Create restrict address record class
 *
 * @package  App
 * @category Filament
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class CreateRestrictAddress extends CreateRecord
{
    protected static string $resource = RestrictAddressResource::class;
    protected static bool $canCreateAnother = false;

    public function form(Form $form): Form
    {
        return $form->schema([
            Components\Textarea::make('recipients')
                ->required()
                ->hint(__('Each recipient is on a line'))
                ->label(__('Recipients')),
            Components\Hidden::make('access')->default('REJECT'),
        ]);
    }

    protected function getTitle(): string
    {
        return __('Create Restrict Addresses');
    }

    protected function getCreatedNotificationTitle(): ?string
    {
        return __('Restrict addresses has been created');
    }

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }

    protected function handleRecordCreation(array $data): Model
    {
        $recipients = self::explodeRecipients($data['recipients']);
        $access = $data['access'];
        if (!empty($recipients)) {
            foreach ($recipients as $recipient) {
                $model = $this->getModel()::firstOrCreate([
                    'recipient' => $recipient,
                    'access' => $access,
                ]);
            }
            return $model;
        }
        else {
            throw new Halt('Error Create Restrict Addresses');
        }
    }

    protected static function explodeRecipients(string $recipients): array
    {
        $addresses = [];
        $lines = array_map(static fn($line) => strtolower(trim($line)), explode(PHP_EOL, trim($recipients)));
        foreach ($lines as $line) {
            if (filter_var($line, FILTER_VALIDATE_EMAIL)) {
                $addresses[] = $line;
            }
            else {
                $parts = array_map(static fn($part) => trim($part), explode(',', $line));
                foreach ($parts as $part) {
                    if (filter_var($part, FILTER_VALIDATE_EMAIL)) {
                        $addresses[] = $part;
                    }
                }
            }
        }
        return $addresses;
    }
}
