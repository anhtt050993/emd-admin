<?php declare(strict_types=1);

namespace App\Filament\Resources\DomainResource\Pages;

use App\Filament\Resources\DomainResource;
use Filament\Resources\Pages\CreateRecord;

/**
 * Create domain record class
 *
 * @package  App
 * @category Filament
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class CreateDomain extends CreateRecord
{
    protected static string $resource = DomainResource::class;

    protected function getCreatedNotificationTitle(): ?string
    {
        return __('Domain has been created');
    }

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
