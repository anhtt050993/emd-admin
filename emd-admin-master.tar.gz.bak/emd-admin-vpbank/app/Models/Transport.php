<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Transport model class
 *
 * @package  App
 * @category Model
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class Transport extends Model
{
    use HasFactory;

    protected $table = 'transports';

    protected $fillable = [
        'name',
        'ip_address',
        'port',
    ];
}
