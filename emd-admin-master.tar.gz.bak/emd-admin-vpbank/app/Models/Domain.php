<?php declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Domain model class
 *
 * @package  App
 * @category Model
 * @author   Nguyen Van Nguyen - nguyennv@iwayvietnam.com
 */
class Domain extends Model
{
    use HasFactory;

    protected $table = 'domains';

    protected $fillable = [
        'name',
        'dkim_selector',
        'dkim_private_key',
        'dkim_public_key',
        'dkim_dns_record',
        'dmarc_dns_record',
        'spf_dns_record',
        'ptr_dns_record',
    ];

    public function clients(): HasMany
    {
        return $this->hasMany(Client::class, 'domain_id', 'id');
    }
}
