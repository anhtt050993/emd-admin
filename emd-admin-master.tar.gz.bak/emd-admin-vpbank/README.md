Email Mass Delivery Web Admin 
=============================

## Requirement
* PHP 8.0.x or later with extensions: Ctype, cURL, DOM, Fileinfo, Filter, Hash,
Mbstring, MySQL native driver, OpenSSL, PCRE, PDO, PDO-MySQL, Session, Tokenizer, XML
* [Laravel](https://laravel.com) framework version 9.x
* [Filament](https://filamentphp.com) Admin Panel version 2.x

## Deployment
When you're ready to deploy your Laravel application to production,
there are some important things you can do to make sure your
application is running as efficiently as possible.
In this document, we'll cover some great starting points
for making sure your Laravel application is deployed properly.

### Nginx Configuration
```
server {
    listen 80;
    listen [::]:80;
    server_name example.com;
    root /srv/example.com/public;
 
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
 
    index index.php;
 
    charset utf-8;
 
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
 
    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }
 
    error_page 404 /index.php;
 
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
 
    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

### Install scripts:
Install composer dependencies
```sh
composer install --optimize-autoloader --no-dev --prefer-dist
```

Copy over example configuration.
Don't forget to set the database config in .env.example correctly
```sh
cp .env.example .env
```

Generate the application key and the jwt secret key. Re-cache.
```sh
php artisan key:generate
php artisan jwt:secret
php artisan config:cache
```

Run database migrations.
```sh
php artisan migrate
```

Create a new user account:
```sh
php artisan make:filament-user
```
