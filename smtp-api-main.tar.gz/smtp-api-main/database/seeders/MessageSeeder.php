<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class MessageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 0; $i < 100; $i++) {
            DB::table('messages')->insert([
                'user_id' => 1,
                'hash' => fake()->uuid(),
                'from_name' => fake()->name(),
                'from_email' => fake()->unique()->safeEmail(),
                'reply_to' => fake()->unique()->safeEmail(),
                'recipients' => json_encode([
                    fake()->unique()->safeEmail(),
                    fake()->unique()->safeEmail(),
                    fake()->unique()->safeEmail(),
                ]),
                'headers' => json_encode([
                    Str::random(10) . ': ' . Str::random(10),
                    Str::random(10) . ': ' . Str::random(10),
                    Str::random(10) . ': ' . Str::random(10),
                ]),
                'message_id' => fake()->uuid(),
                'subject' => fake()->sentence(),
                'content' => fake()->randomHtml(),
                'ip_address' => fake()->ipv4(),
                'sent_at' => fake()->dateTime(),
                'created_at' => fake()->dateTime(),
            ]);
        }
    }
}
