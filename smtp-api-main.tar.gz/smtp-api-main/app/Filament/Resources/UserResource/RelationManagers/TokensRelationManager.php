<?php declare(strict_types=1);

namespace App\Filament\Resources\UserResource\RelationManagers;

use Filament\Resources\RelationManagers\RelationManager;
use Filament\Resources\Table;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Columns\TextColumn;

/**
 * User tokens relation manager.
 *
 * @package  App
 * @category Resources
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class TokensRelationManager extends RelationManager
{
    protected static string $relationship = 'tokens';

    public static function getTitle(): string
    {
        return __('Access Tokens');
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->label(__('Name')),
            TextColumn::make('token')->label(__('Token')),
            TextColumn::make('last_used_at')->dateTime()->label(__('Last Used At')),
            TextColumn::make('expires_at')->dateTime()->label(__('Expires At')),
        ])->actions([
            DeleteAction::make(),
        ]);
    }
}
