<?php declare(strict_types=1);

namespace App\Filament\Resources\MessageResource\RelationManagers;

use Filament\Resources\Table;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables\Actions\Action;
use Filament\Tables\Columns\TextColumn;
use Illuminate\Support\Facades\Storage;

/**
 * Message attachments relation manager.
 *
 * @package  App
 * @category Resources
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class AttachmentsRelationManager extends RelationManager
{
    protected static string $relationship = 'attachments';

    public static function getTitle(): string
    {
        return __('Attachments');
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('file_name')->label(__('File Name')),
            TextColumn::make('file_mime')->label(__('File Mime')),
            TextColumn::make('file_size')->label(__('File Size')),
        ])->actions([
            Action::make('download')->label(__('Download'))->action(
                fn ($record) => Storage::download($record->file_path)
            )
        ]);
    }
}
