<?php declare(strict_types=1);

namespace App\Filament\Resources\MessageResource\Pages;

use App\Filament\Resources\MessageResource;
use Filament\Forms\Components\{
    Textarea,
    TextInput,
};
use Filament\Pages\Actions\DeleteAction;
use Filament\Resources\Form;
use Filament\Resources\Pages\ViewRecord;

/**
 * View message page.
 *
 * @package  App
 * @category Resources
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class ViewMessage extends ViewRecord
{
    protected static string $resource = MessageResource::class;

    protected function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('from_name')->label(__('From Name')),
            TextInput::make('from_email')->email()->label(__('From Email')),
            TextInput::make('reply_to')->email()->label(__('Reply To')),
            TextInput::make('ip_address')->label(__('IP Address')),
            TextInput::make('recipients')->label(__('Recipients'))->columnSpan(2),
            TextInput::make('subject')->label(__('Subject'))->columnSpan(2),
            Textarea::make('content')->label(__('Content'))->columnSpan(2),
            TextInput::make('last_opened')->label(__('Last Opened')),
            TextInput::make('hash')->label(__('Tracking Hash')),
        ]);
    }

    protected function getActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }

    protected function mutateFormDataBeforeFill(array $data): array
    {
        $data['recipients'] = implode(', ', $data['recipients']);
        $data['headers']    = implode(', ', $data['headers']);
        return $data;
    }
}
