<?php declare(strict_types=1);

namespace App\Filament\Resources;

use App\Models\Message;
use Filament\Resources\{
    Resource,
    Table,
};
use Filament\Tables\Actions\{
    DeleteAction,
    ViewAction,
};
use Filament\Tables\Columns\TextColumn;

/**
 * Message resource manager.
 *
 * @package  App
 * @category Resources
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class MessageResource extends Resource
{
    protected static ?string $model = Message::class;
    protected static ?string $navigationIcon = 'heroicon-o-mail';
    protected static ?string $slug = 'message';

    protected static function getNavigationGroup(): string
    {
        return __('Message');
    }

    protected static function getNavigationLabel(): string
    {
        return __('Messages');
    }

    public static function getModelLabel(): string
    {
        return __('Message');
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('subject')->label(__('Subject'))->wrap(),
            TextColumn::make('from_email')->label(__('Sender')),
            TextColumn::make('open_count')->label(__('Open Count')),
            TextColumn::make('sent_at')->label(__('Sent At'))->dateTime()->sortable(),
        ])->defaultSort('sent_at', 'desc')->actions([
            ViewAction::make(),
            DeleteAction::make(),
        ])->bulkActions([]);
    }
    
    public static function getRelations(): array
    {
        return [
            MessageResource\RelationManagers\AttachmentsRelationManager::class,
            MessageResource\RelationManagers\DevicesRelationManager::class,
        ];
    }
    
    public static function getPages(): array
    {
        return [
            'index' => MessageResource\Pages\ListMessages::route('/'),
            'view'  => MessageResource\Pages\ViewMessage::route('/{record}'),
        ];
    }    
}
