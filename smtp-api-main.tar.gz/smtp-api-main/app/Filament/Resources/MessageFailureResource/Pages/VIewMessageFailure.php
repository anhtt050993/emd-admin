<?php declare(strict_types=1);

namespace App\Filament\Resources\MessageFailureResource\Pages;

use App\Filament\Resources\MessageFailureResource;
use App\Models\Message;
use Filament\Forms\Components\{
    Textarea,
    TextInput,
};
use Filament\Pages\Actions\DeleteAction;
use Filament\Resources\Form;
use Filament\Resources\Pages\ViewRecord;

/**
 * View message failure page.
 *
 * @package  App
 * @category Resources
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class VIewMessageFailure extends ViewRecord
{
    protected static string $resource = MessageFailureResource::class;

    protected function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('message_subject')->label(__('Message Subject')),
            TextInput::make('message_id')->label(__('Message ID')),
            TextInput::make('from_email')->label(__('Sender')),
            TextInput::make('severity')->label(__('Severity')),
            Textarea::make('description')->label(__('Description')),
            TextInput::make('failed_at')->label(__('Failed At')),
        ]);
    }

    protected function getActions(): array
    {
        return [
            DeleteAction::make(),
        ];
    }

    protected function mutateFormDataBeforeFill(array $data): array
    {
        $message = Message::find($data['message_id']);
        $data['message_subject'] = $message?->subject ?? '';
        $data['message_id'] = $message?->message_id ?? '';
        $data['from_email'] = $message?->from_email ?? '';
        return $data;
    }
}
