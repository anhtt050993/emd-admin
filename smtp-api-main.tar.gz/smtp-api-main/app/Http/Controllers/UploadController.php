<?php declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Cache;

/**
 * Upload controller.
 *
 * @package  App
 * @category Controllers
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class UploadController extends Controller
{
    const UPLOAD_DIR = 'attachments';

    /**
     * Upload files.
     *
     * @param  Request $request
     * @return JsonResource
     */
    public function upload(Request $request): JsonResource
    {
        $storeDir = self::UPLOAD_DIR . '/' . $request->user()->email;
        $files = [];
        foreach ($request->allFiles() as $file) {
            $files[] = $file->hashName();
            Cache::put(
                $file->hashName(),
                $file->store($storeDir),
                3600
            );
        }
        JsonResource::withoutWrapping();
        return new JsonResource($files);
    }
}
