<?php declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\{
    Hash,
    RateLimiter,
};
use Illuminate\Validation\ValidationException;

/**
 * Login controller.
 *
 * @package  App
 * @category Controllers
 * @author   Nguyen Van Nguyen - nguyennv1981@gmail.com
 */
class LoginController extends Controller
{
    /**
     * Create an access token.
     *
     * @return JsonResource
     */
    public function createToken(Request $request): JsonResource
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
            'device'   => 'required',
        ]);

        if (RateLimiter::tooManyAttempts(
            'create-token:' . $request->email, 1
        )) {
            throw new ThrottleRequestsException(
                'Too many access token creating attempts!'
            );
        }
        $decaySeconds = (int) env('CREATE_TOKEN_DECAY_SECONDS', 3600);
        RateLimiter::hit('create-token:' . $request->email, $decaySeconds);

        $user = User::where('email', $request->email)->first();
        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        $expiresAt = null;
        if (($expiration = config('sanctum.expiration')) !== null) {
            $expiresAt = now()->addMinutes((int) $expiration);
        }

        JsonResource::withoutWrapping();
        return new JsonResource([
            'token' => $user->createToken(
                $request->device, [
                    'api-email',
                    'api-upload',
                ],
                expiresAt: $expiresAt,
            )->plainTextToken,
            'expires_at' => $expiresAt,
        ]);
    }
}
