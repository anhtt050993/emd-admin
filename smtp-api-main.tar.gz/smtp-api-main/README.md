SMTP API
========

## Requirement
* PHP 8.0.x or later with extensions: Ctype, cURL, DOM, Fileinfo, Filter, Hash,
Mbstring, MySQL native driver, OpenSSL, PCRE, PDO, PDO-MySQL, Session, Tokenizer, XML
* [Laravel](https://laravel.com) framework version 9.x
* [Filament](https://filamentphp.com) Admin Panel version 2.x

## Deployment
When you're ready to deploy your Laravel application to production,
there are some important things you can do to make sure your
application is running as efficiently as possible.
In this document, we'll cover some great starting points
for making sure your Laravel application is deployed properly.

### Nginx Configuration
```nginx
server {
    listen 80;
    listen [::]:80;
    server_name example.com;
    root /srv/example.com/public;
 
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
 
    index index.php;
 
    charset utf-8;
 
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
 
    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }
 
    error_page 404 /index.php;
 
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
 
    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

### Installation
Install composer dependencies
```sh
composer install --optimize-autoloader --no-dev --prefer-dist
```

Copy over example configuration.
Don't forget to set the database config in .env.example correctly
```sh
cp .env.example .env
```

Environment variables:
| Name              | Description              | Default                |
|-------------------|--------------------------|------------------------|
| APP_NAME          | Application Name         | SMTP API               |
| APP_ENV           | Application Environment  | production             |
| APP_KEY           | Encryption Key           | null                   |
| APP_DEBUG         | Application Debug Mode   | false                  |
| APP_URL           | Application URL          | http://api.example.com |
| DB_CONNECTION     | Database Connection Name | mysql                  |
| DB_HOST           | Database Host            | 127.0.0.1              |
| DB_PORT           | Database Port            | 3306                   |
| DB_DATABASE       | Database Name            | laravel                |
| DB_USERNAME       | Database User Name       | root                   |
| DB_PASSWORD       | Database User Password   | null                   |
| MAIL_MAILER       | Default Mailer           | smtp                   |
| MAIL_HOST         | Mail Host Name           | smtp.example.com       |
| MAIL_PORT         | Mail Port                | 587                    |
| MAIL_ENCRYPTION   | Mail Encryption          | tls                    |
| MAIL_USERNAME     | Mail User Name           | null                   |
| MAIL_PASSWORD     | Mail User Password       | null                   |
| MAIL_EHLO_DOMAIN  | Mail Ehlo Domain         | null                   |
| MAIL_QUEUE_NAME   | Mail Queue Name          | emails                 |
| MAIL_SHOULD_QUEUE | Message Should Queue     | false                  |
| MAIL_TRACK_CLICK  | Mail Track Click         | false                  |
| QUEUE_CONNECTION  | Queue Connection Name    | sync                   |
| API_REQUEST_PER_MINUTE | api request per minute | 60                  |

Generate the application key and the jwt secret key. Re-cache.
```sh
php artisan key:generate
php artisan config:cache
```

Run database migrations.
```sh
php artisan migrate
```

Create a new user account:
```sh
php artisan make:filament-user
```

### Process Queued Messages
Run command that will process messages as they are pushed onto the queue:
```sh
php artisan queue:work --queue=emails --tries=3
```

Retrying failed messages
```sh
php artisan queue:retry --queue=emails
```

### API Usage
* Define base api url & create http client:
```php
define('BASE_API_URL', 'http://api.example.com');
$jar = new \GuzzleHttp\Cookie\CookieJar();
$client = new \GuzzleHttp\Client([
    'base_uri' => BASE_API_URL,
    'cookies' => $jar,
]);
```

* Authentication (obtain access token):
```php
$client->get(
    'login/csrf-cookie'
);
$xsrfToken = $jar->getCookieByName('XSRF-TOKEN')->getValue();
$response = $client->post(
    'login/token', [
        'headers' => [
            'X-XSRF-TOKEN' => urldecode($xsrfToken),
        ],
        'form_params' => [
            'email' => $email,
            'password' => $password,
            'device' => $device,
        ],
    ]
);
$accessToken = json_decode($response->getBody());
```

* Files uploading (for attachment)
```php
$response = $client->post(
    'api/upload', [
        'headers' => [
            'Authorization' => 'Bearer ' . $accessToken->token,
            'Accept' => 'application/json',
        ],
        'multipart' => [
            [
                'name' => 'name-01',
                'contents' => fopen('path-to-the-file', 'rb'),
                'filename' => 'filename-01',
            ],
            [
                'name' => 'name-02',
                'contents' => fopen('path-to-the-file', 'rb'),
                'filename' => 'filename-02',
            ],
        ],
    ]
);
$uploads = json_decode($response->getBody());
```

* Message sending
```php
$response = $client->post(
    'api/send', [
        'headers' => [
            'Authorization' => 'Bearer ' . $accessToken->token,
            'Accept' => 'application/json',
        ],
        'form_params' => [
            'recipients' => [
                $email01,
                $email02,
            ],
            'headers' => [
                'Header-01: Value 01',
                'Header-02: Value 02',
            ],
            'message_id' => $message_id,
            'subject' => $subject,
            'content' => $content,
            'uploads' => $uploads,
        ],
    ]
);
$message = json_decode($response->getBody());
```

* Message listing
```php
$response = $client->get(
    'api/email', [
        'headers' => [
            'Authorization' => 'Bearer ' . $accessToken->token,
            'Accept' => 'application/json',
        ],
    ]
);
$messages = json_decode($response->getBody());
```

* Message viewing
```php
$response = $client->get(
    'api/email/1', [
        'headers' => [
            'Authorization' => 'Bearer ' . $accessToken->token,
            'Accept' => 'application/json',
        ],
    ]
);
$message = json_decode($response->getBody());
```

* Message tracking device listing
```php
$response = $client->get(
    'api/email/1/devices', [
        'headers' => [
            'Authorization' => 'Bearer ' . $accessToken->token,
            'Accept' => 'application/json',
        ],
    ]
);
$devices = json_decode($response->getBody());
```

### Rate Limiting
* Authentication restrict the amount of auth token creating for a given email address by 1 request per hour
* API restrict the amount of traffic for a given user by 60 request per minute
